Gurkirat Singh Dhatt-Programmer Author
101211491 

The purpose of this project is to submit assignment 1 for COMP 2404. 
This will execute and run a room booking application, where students can book a room any day and time and can search rooms that match their criteria and check avaliability. 

List of Files

Source Files:
a1.global.cc
Date.cc
a1.cpp
reservation.cc
student.cc
library.cc
room.cc

Header Files:
Date.h
reservation.h
room.h
student.h
library.h

No data files

To compile and launch the make file in this zip file 
Complaition command make all or also make a1
Launch is ./a1
for valgrind it is, valgrind ./a1





