Gurkirat Singh Dhatt-Programmer Author

This will execute and run a room booking application, where people can book a room any day and time and can search rooms that match their criteria and check avaliability. 

List of Files

Source Files:
a1.global.cc
Date.cc
main.cc
reservation.cc
student.cc
library.cc
room.cc

Header Files:
Date.h
reservation.h
room.h
student.h
library.h

No data files

To compile and launch the make file in this zip file 
Complaition command make or also make a1
Launch is ./a1
for valgrind it is, valgrind ./a1





